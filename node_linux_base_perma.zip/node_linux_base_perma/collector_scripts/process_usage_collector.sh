#!/bin/bash
##ResursiveLoop Inc 2024
##Lunar Angelo Pajaroja
##File Collector / Process /Node Exporter Script
##v1.1.0 Seperates Process and Storage dues to recource consumption of du and find (runs only 'Twice' ;) a day)
##v1.2.0 Add top 5 memory consumer/user
##v1.3.0 Replace top with ps for more static data (top may snap 0 value data)
##v1.4.0 Utilize smem for external clients (memory utilization)


node_dir=/etc/node_exporter
temp_file_dir=$node_dir/temp

mkdir $temp_file_dir 2> /dev/null

#Collect top5 process

ps -eo %cpu,pid,comm --sort=-%cpu | head -21 | tail -n +2 | expand | sed 's/  */ /g' | awk '{print $3" "$1" "$2}' > $temp_file_dir/top5_proc

while IFS=' ' read -r process value pid ignored; do
    echo top5_process{process='"'$process'"'','pid='"'$pid'"'} $value
done < $temp_file_dir/top5_proc > $node_dir/process.prom

#Collect top5 memory user

smem -c "uss pid command" -s uss -r | head -21 | tail -n +2 | expand | sed 's/  */ /g' | awk '{print $3" "$1" "$2}' > $temp_file_dir/top5_mem


while IFS=' ' read -r process value pid ignored; do
    echo top5_memory{process='"'$process'"'','pid='"'$pid'"'} $value
done < $temp_file_dir/top5_mem > $node_dir/memory.prom