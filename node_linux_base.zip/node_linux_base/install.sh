#!/bin/bash
#Lunar Angelo Pajaroja

eod=1731211200 #November 10 2024 12:00PM PHT
uct=`date +%s`

### ONGOING
if [ "$eod" -gt "$uct" ]; then
       
run=`cat /proc/1/comm`
cpu=`uname -m`

### DEV/TEST
#cpu=arch64
#run=sysinit

bin_dir=/usr/local/bin
systemd_dir=/etc/systemd/system
initd_dir=/etc/init.d
node_exporter_dir=/etc/node_exporter

cron_process="*/1 * * * * /etc/node_exporter/process_usage_collector.sh"
cron_storage="0 */12 * * * /etc/node_exporter/storage_usage_collector.sh"

## Check CPU architecture

echo "Checking CPU architecture"

if echo "$cpu" | grep -q "86_64" || echo "$cpu" | grep -q "amd64"; then
        binary=amd
	echo "CPU amd family"
    elif echo "$cpu" | grep -q "arch64" || echo "$cpu" | grep -q "arm64"; then
        binary=arm
	echo "CPU arm family"
    else
        echo "CPU architechture not found"
fi

## Functions

base_setup() {
    useradd -M -r -s /bin/false node_exporter
    mkdir $node_exporter_dir
}

run_initd() {
    cp ./node_exporter_binary/node_exporter_$binary $bin_dir/node_exporter
    cp ./system_init/node_exporter_service $initd_dir/node_exporter
    chmod +x $initd_dir/node_exporter

    chkconfig --add node_exporter 
    service node_exporter start
    chkconfig node_exporter on
    
    if pidof node_exporter 2>&1 /dev/null; then
        echo "node_exporter is running under initd"
    else
        echo "node_exporter failed to start under initd"
    fi

}

run_systemd() {
    cp ./node_exporter_binary/node_exporter_$binary $bin_dir/node_exporter
    chown node_exporter:node_exporter $bin_dir/node_exporter
    cp ./system_init/node_exporter_systemctl $systemd_dir/node_exporter.service

    systemctl daemon-reload
    systemctl start node_exporter
    systemctl enable node_exporter

if (systemctl is-active --quiet node_exporter); then
        echo "node_exporter is running under systemd"
    else
	echo "node_exporter failed to start under systemd"
    fi

}

collector_scripts() {
    cp ./collector_scripts/* $node_exporter_dir
    chmod +x $node_exporter_dir/*.sh

    # Check if the cron job for process collector exists
    if ! (crontab -l | grep -Fxq "$cron_process"); then
        (crontab -l; echo "$cron_process") | crontab -
    else
        echo "Process Collector Script job already exists"
    fi

    # Check if the cron job for storage collector exists
    if ! (crontab -l | grep -Fxq "$cron_storage"); then
        (crontab -l; echo "$cron_storage") | crontab -
    else
        echo "Storage Collector Script job already exists"
    fi
}

## Rune base setup

echo "Running base setup"
base_setup

## Check init system

if [ "$run" = "systemd" ]; then
        echo "Init system found systemd"
	run_systemd
    elif echo "$run" | grep -q "init"; then
        echo "Init system found initd"
        run_initd
    else
        echo "Init system not found"
fi

## Setup collector scripts

echo "Copying collector scripts"
collector_scripts

### EXPIRED
else
        echo "Expired"
fi

