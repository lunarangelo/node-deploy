#!/bin/bash
##TechByte Systems
##File Collector / Node Exporter Script
##TechByte Systems v1.0.0.0
##v1.1.0 Seperates Process and Storage dues to recource consumption of du and find (runs only Twice a day)

eod=1731211200 #November 10 2024 12:00PM PHT
uct=`date +%s`

### ONGOING
if [ "$eod" -gt "$uct" ]; then

node_dir=/etc/node_exporter
temp_file_dir=$node_dir/temp

mkdir $temp_file_dir 2> /dev/null

#Collect top5 largest dirs

du -S / 2> /dev/null | sort -rh | head -5 | expand | sed 's/  */ /g' | awk '{ print $2" "$1 }' > $temp_file_dir/top5_dirs

while IFS=' ' read -r dirs value ignored; do
    echo top5_dirs{dirs='"'$dirs'"'} $value
done < $temp_file_dir/top5_dirs > $node_dir/dirs.prom


#Collect top5 largest files

find / -type f -size +50M 2> /dev/null | xargs du -s | sort -n -r | head -5 | expand | sed 's/  */ /g' | awk '{ print $2" "$1 }' > $temp_file_dir/top5_files

while IFS=' ' read -r files value ignored; do
    echo top5_files{files='"'$files'"'} $value
done < $temp_file_dir/top5_files > $node_dir/files.prom

### EXPIRED
else
        echo "Expired"
fi
